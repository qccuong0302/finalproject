create database computershop
use computershop
create table newComputer(
	cid int NOT NULL IDENTITY(1,1) primary key,
	bname varchar(250) not null,
	mname varchar(250) not null,
	ram varchar(250) not null,
	storage varchar(250) not null,
	display varchar(250) not null,
	battery varchar(250) not null,
	cpu varchar(250) not null,
	vga varchar(250) not null,
	wei varchar(250) not null,
	price varchar(250) not null
);
drop table newComputer
select * from newComputer

create table customerPurchase(
	pid int not null IDENTITY(1,1) primary key,
	cname varchar(250) not null,
	gender varchar(50) not null,
	contact varchar(250) not null,
	email varchar(250) not null,
	addr varchar(250) not null,
	idcard varchar(250) not null,
	brand varchar(250) not null,
	model varchar(250) not null
);

select * from customerPurchase