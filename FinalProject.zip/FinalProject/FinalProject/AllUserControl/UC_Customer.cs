﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.AllUserControl
{
    public partial class UC_Customer : UserControl
    {
        function fn = new function();
        String query;
        public UC_Customer()
        {
            InitializeComponent();
        }

        public void setComboBOX(String query, ComboBox combo)
        {
            SqlDataReader sdr = fn.getForCombo(query);
            while (sdr.Read())
            {
                for(int i=0; i<sdr.FieldCount; i++)
                {
                    combo.Items.Add(sdr.GetString(i));
                }
            }
        }

        private void UC_Customer_Enter(object sender, EventArgs e)
        {
            txtBrand.Items.Clear();
            query = "select distinct bname from newComputer";
            setComboBOX(query, txtBrand);
        }

        private void txtBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtModel.Items.Clear();
            String bname = txtBrand.Text;
            query = "select mname from newComputer where bname = '"+bname+"'";
            setComboBOX(query, txtModel);
        }

        private void txtModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            query = "select * from newComputer where mname = '"+txtModel.Text+"'";
            DataSet ds = fn.getData(query);

            ramlabel.Text = ds.Tables[0].Rows[0][3].ToString();
            storagelabel.Text = ds.Tables[0].Rows[0][4].ToString();
            displaylabel.Text = ds.Tables[0].Rows[0][5].ToString();
            batterylabel.Text = ds.Tables[0].Rows[0][6].ToString();
            cpulabel.Text = ds.Tables[0].Rows[0][7].ToString();
            vgalabel.Text = ds.Tables[0].Rows[0][8].ToString();
            weightlabel.Text = ds.Tables[0].Rows[0][9].ToString();
            pricelabel.Text = ds.Tables[0].Rows[0][10].ToString();
        }

        private void btnPurchase_Click(object sender, EventArgs e)
        {
            if(txtName.Text != "" && txtGender.Text != "" && txtContact.Text != "" 
                && txtEmail.Text != "" && txtAddress.Text != "" && txtBrand.Text != "" 
                && txtModel.Text != "" && txtIDCard.Text != "")
            {
                String name = txtName.Text;
                String gender = txtGender.Text;
                String contact = txtContact.Text;
                String email = txtEmail.Text;
                String addr = txtAddress.Text;
                String brand = txtBrand.Text;
                String model = txtModel.Text;
                String idcard = txtIDCard.Text;

                query = "insert into customerPurchase (cname, gender, contact, email, addr, idcard, brand, model) values ('"+name+"', '"+gender+"', '"+contact+"', '"+email+"', '"+addr+"', '"+idcard+"', '"+brand+"', '"+model+"')";
                fn.setData(query);
            }
            else
            {
                MessageBox.Show("Fill all the fields", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }
    }
}
