﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject.AllUserControl
{
    public partial class UC_AddNewComputer : UserControl
    {
        function fn = new function();
        String query;

        public UC_AddNewComputer()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtBrand.Text != "" && txtModel.Text != "" && txtRam.Text != "" && txtStorage.Text != "" 
                && txtCPU.Text != "" && txtBattery.Text != "" && txtDisplay.Text != "" && txtVGA.Text != "" 
                && txtWeight.Text != "" && txtPrice.Text != "")
            {
                String brand = txtBrand.Text;
                String model = txtModel.Text;
                String ram = txtRam.Text;
                String storage = txtStorage.Text;
                String cpu = txtCPU.Text;
                String battery = txtBattery.Text;
                String display = txtDisplay.Text;
                String vga = txtVGA.Text;
                String weight = txtWeight.Text;
                String price = txtPrice.Text;

                query = "insert into newComputer (bname, mname, ram, storage, display, battery, cpu, vga, wei, price) values ('"+brand+"', '"+model+"', '"+ram+"', '"+storage+"', '"+display+"', '"+battery+"', '"+cpu+"', '"+vga+"', '"+weight+"', '"+price+"')";
                fn.setData(query);
            }
            else
            {
                MessageBox.Show("Fill All Data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
           
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtBrand.Clear();
            txtModel.Clear();
            txtCPU.Clear();
            txtBattery.Clear();
            txtVGA.Clear();
            txtWeight.Clear();
            txtPrice.Clear();
            txtStorage.Clear();
            txtDisplay.StartIndex = -1;
            txtRam.StartIndex = -1;
        }
    }
}
