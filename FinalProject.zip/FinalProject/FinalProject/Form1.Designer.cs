﻿
namespace FinalProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancel = new Guna.UI2.WinForms.Guna2Button();
            this.btnVerify = new Guna.UI2.WinForms.Guna2Button();
            this.txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.btnCustomerRecords = new Guna.UI2.WinForms.Guna2Button();
            this.btnStock = new Guna.UI2.WinForms.Guna2Button();
            this.btnCustomers = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddNewComputer = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.uC_Login1 = new FinalProject.AllUserControl.UC_Login();
            this.uC_DeletePhoneRecord1 = new FinalProject.AllUserControl.UC_DeleteComputerRecord();
            this.uC_CustomerRecords1 = new FinalProject.AllUserControl.UC_CustomerRecords();
            this.uC_Stock1 = new FinalProject.AllUserControl.UC_Stock();
            this.uC_AddNewComputer1 = new FinalProject.AllUserControl.UC_AddNewComputer();
            this.uC_Customer1 = new FinalProject.AllUserControl.UC_Customer();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.btnVerify);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.guna2Button5);
            this.panel1.Controls.Add(this.btnCustomerRecords);
            this.panel1.Controls.Add(this.btnStock);
            this.panel1.Controls.Add(this.btnCustomers);
            this.panel1.Controls.Add(this.btnAddNewComputer);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(206, 563);
            this.panel1.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.CheckedState.Parent = this.btnCancel;
            this.btnCancel.CustomImages.Parent = this.btnCancel;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.HoverState.Parent = this.btnCancel;
            this.btnCancel.Location = new System.Drawing.Point(113, 365);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.ShadowDecoration.Parent = this.btnCancel;
            this.btnCancel.Size = new System.Drawing.Size(90, 31);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnVerify
            // 
            this.btnVerify.CheckedState.Parent = this.btnVerify;
            this.btnVerify.CustomImages.Parent = this.btnVerify;
            this.btnVerify.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnVerify.ForeColor = System.Drawing.Color.White;
            this.btnVerify.HoverState.Parent = this.btnVerify;
            this.btnVerify.Location = new System.Drawing.Point(3, 365);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.ShadowDecoration.Parent = this.btnVerify;
            this.btnVerify.Size = new System.Drawing.Size(90, 31);
            this.btnVerify.TabIndex = 4;
            this.btnVerify.Text = "Verify";
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPassword.DefaultText = "";
            this.txtPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassword.DisabledState.Parent = this.txtPassword;
            this.txtPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassword.FocusedState.Parent = this.txtPassword;
            this.txtPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassword.HoverState.Parent = this.txtPassword;
            this.txtPassword.Location = new System.Drawing.Point(3, 313);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '.';
            this.txtPassword.PlaceholderText = "";
            this.txtPassword.SelectedText = "";
            this.txtPassword.ShadowDecoration.Parent = this.txtPassword;
            this.txtPassword.Size = new System.Drawing.Size(200, 36);
            this.txtPassword.TabIndex = 4;
            // 
            // guna2Button5
            // 
            this.guna2Button5.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button5.CheckedState.FillColor = System.Drawing.Color.White;
            this.guna2Button5.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Location = new System.Drawing.Point(3, 252);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(200, 45);
            this.guna2Button5.TabIndex = 4;
            this.guna2Button5.Text = "Delete Computer Record";
            this.guna2Button5.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // btnCustomerRecords
            // 
            this.btnCustomerRecords.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnCustomerRecords.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnCustomerRecords.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnCustomerRecords.CheckedState.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.CustomImages.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCustomerRecords.ForeColor = System.Drawing.Color.White;
            this.btnCustomerRecords.HoverState.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.Location = new System.Drawing.Point(3, 201);
            this.btnCustomerRecords.Name = "btnCustomerRecords";
            this.btnCustomerRecords.ShadowDecoration.Parent = this.btnCustomerRecords;
            this.btnCustomerRecords.Size = new System.Drawing.Size(200, 45);
            this.btnCustomerRecords.TabIndex = 3;
            this.btnCustomerRecords.Text = "Customer Records";
            this.btnCustomerRecords.Click += new System.EventHandler(this.btnCustomerRecords_Click);
            // 
            // btnStock
            // 
            this.btnStock.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnStock.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnStock.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnStock.CheckedState.Parent = this.btnStock;
            this.btnStock.CustomImages.Parent = this.btnStock;
            this.btnStock.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnStock.ForeColor = System.Drawing.Color.White;
            this.btnStock.HoverState.Parent = this.btnStock;
            this.btnStock.Location = new System.Drawing.Point(3, 150);
            this.btnStock.Name = "btnStock";
            this.btnStock.ShadowDecoration.Parent = this.btnStock;
            this.btnStock.Size = new System.Drawing.Size(200, 45);
            this.btnStock.TabIndex = 2;
            this.btnStock.Text = "Stock";
            this.btnStock.Click += new System.EventHandler(this.btnStock_Click);
            // 
            // btnCustomers
            // 
            this.btnCustomers.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnCustomers.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnCustomers.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnCustomers.CheckedState.Parent = this.btnCustomers;
            this.btnCustomers.CustomImages.Parent = this.btnCustomers;
            this.btnCustomers.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCustomers.ForeColor = System.Drawing.Color.White;
            this.btnCustomers.HoverState.Parent = this.btnCustomers;
            this.btnCustomers.Location = new System.Drawing.Point(3, 99);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.ShadowDecoration.Parent = this.btnCustomers;
            this.btnCustomers.Size = new System.Drawing.Size(200, 45);
            this.btnCustomers.TabIndex = 1;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.Click += new System.EventHandler(this.btnCustomers_Click);
            // 
            // btnAddNewComputer
            // 
            this.btnAddNewComputer.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnAddNewComputer.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnAddNewComputer.CheckedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnAddNewComputer.CheckedState.Parent = this.btnAddNewComputer;
            this.btnAddNewComputer.CustomImages.Parent = this.btnAddNewComputer;
            this.btnAddNewComputer.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAddNewComputer.ForeColor = System.Drawing.Color.White;
            this.btnAddNewComputer.HoverState.Parent = this.btnAddNewComputer;
            this.btnAddNewComputer.Location = new System.Drawing.Point(3, 48);
            this.btnAddNewComputer.Name = "btnAddNewComputer";
            this.btnAddNewComputer.ShadowDecoration.Parent = this.btnAddNewComputer;
            this.btnAddNewComputer.Size = new System.Drawing.Size(200, 45);
            this.btnAddNewComputer.TabIndex = 0;
            this.btnAddNewComputer.Text = "Add New Computer";
            this.btnAddNewComputer.Click += new System.EventHandler(this.btnAddNewComputer_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.uC_Login1);
            this.panel2.Controls.Add(this.uC_DeletePhoneRecord1);
            this.panel2.Controls.Add(this.uC_CustomerRecords1);
            this.panel2.Controls.Add(this.uC_Stock1);
            this.panel2.Controls.Add(this.uC_AddNewComputer1);
            this.panel2.Controls.Add(this.uC_Customer1);
            this.panel2.Location = new System.Drawing.Point(224, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(774, 563);
            this.panel2.TabIndex = 1;
            // 
            // uC_Login1
            // 
            this.uC_Login1.BackColor = System.Drawing.Color.White;
            this.uC_Login1.Location = new System.Drawing.Point(51, -10);
            this.uC_Login1.Name = "uC_Login1";
            this.uC_Login1.Size = new System.Drawing.Size(480, 563);
            this.uC_Login1.TabIndex = 5;
            this.uC_Login1.SizeChanged += new System.EventHandler(this.uC_Login1_SizeChanged);
            // 
            // uC_DeletePhoneRecord1
            // 
            this.uC_DeletePhoneRecord1.BackColor = System.Drawing.Color.White;
            this.uC_DeletePhoneRecord1.Location = new System.Drawing.Point(0, 3);
            this.uC_DeletePhoneRecord1.Name = "uC_DeletePhoneRecord1";
            this.uC_DeletePhoneRecord1.Size = new System.Drawing.Size(774, 563);
            this.uC_DeletePhoneRecord1.TabIndex = 4;
            // 
            // uC_CustomerRecords1
            // 
            this.uC_CustomerRecords1.BackColor = System.Drawing.Color.White;
            this.uC_CustomerRecords1.Location = new System.Drawing.Point(-3, 3);
            this.uC_CustomerRecords1.Name = "uC_CustomerRecords1";
            this.uC_CustomerRecords1.Size = new System.Drawing.Size(774, 563);
            this.uC_CustomerRecords1.TabIndex = 3;
            // 
            // uC_Stock1
            // 
            this.uC_Stock1.BackColor = System.Drawing.Color.White;
            this.uC_Stock1.Location = new System.Drawing.Point(-3, 0);
            this.uC_Stock1.Name = "uC_Stock1";
            this.uC_Stock1.Size = new System.Drawing.Size(774, 563);
            this.uC_Stock1.TabIndex = 2;
            // 
            // uC_AddNewComputer1
            // 
            this.uC_AddNewComputer1.BackColor = System.Drawing.Color.White;
            this.uC_AddNewComputer1.Location = new System.Drawing.Point(0, 3);
            this.uC_AddNewComputer1.Name = "uC_AddNewComputer1";
            this.uC_AddNewComputer1.Size = new System.Drawing.Size(774, 563);
            this.uC_AddNewComputer1.TabIndex = 1;
            // 
            // uC_Customer1
            // 
            this.uC_Customer1.BackColor = System.Drawing.Color.White;
            this.uC_Customer1.Location = new System.Drawing.Point(0, 0);
            this.uC_Customer1.Name = "uC_Customer1";
            this.uC_Customer1.Size = new System.Drawing.Size(774, 563);
            this.uC_Customer1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 577);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Button btnAddNewComputer;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button btnCustomerRecords;
        private Guna.UI2.WinForms.Guna2Button btnStock;
        private Guna.UI2.WinForms.Guna2Button btnCustomers;
        private AllUserControl.UC_CustomerRecords uC_CustomerRecords1;
        private AllUserControl.UC_Stock uC_Stock1;
        private AllUserControl.UC_AddNewComputer uC_AddNewComputer1;
        private AllUserControl.UC_Customer uC_Customer1;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnVerify;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private AllUserControl.UC_DeleteComputerRecord uC_DeletePhoneRecord1;
        private AllUserControl.UC_Login uC_Login1;
    }
}

